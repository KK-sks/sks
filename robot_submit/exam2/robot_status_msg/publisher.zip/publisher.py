import rclpy
from rclpy.node import Node
from std_msgs.msg import String  # 导入字符串消息类型

class RobotStatusPublisher(Node):
    def __init__(self):
        super().__init__('robot_status_publisher')  # 节点名称为 'robot_status_publisher'
        
        # 创建一个发布者，发布话题名为 'robot_status'，消息类型为 String
        self.publisher_ = self.create_publisher(String, 'robot_status', 10)
        
        # 创建一个定时器，每隔 1.0 秒（1000ms）触发一次回调函数
        timer_period = 1.0  
        self.timer = self.create_timer(timer_period, self.timer_callback)
        
        self.i = 0  # 用于计数，发布第几条消息

    def timer_callback(self):
        # 创建消息对象
        msg = String()
        # 设置消息内容，这里发布一个简单的状态字符串
        msg.data = f'Robot is running... Count: {self.i}' 
        
        # 发布消息
        self.publisher_.publish(msg)
        
        # 打印日志到终端
        self.get_logger().info(f'Publishing: "{msg.data}"')
        
        self.i += 1  # 计数器加 1

def main(args=None):
    rclpy.init(args=args)  # 初始化 ROS2 客户端库

    # 创建并发布者节点实例
    robot_publisher = RobotStatusPublisher()

    # 保持节点运行，直到被销毁
    rclpy.spin(robot_publisher)

    # 销毁节点，释放资源
    robot_publisher.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
